This directory contains the Catapult eslint config, custom Catapult eslint rules,
and tests for those rules.

Some of our custom rules are modified versions of those included with eslint, as
suggested in https://goo.gl/uAxFHq.
